### Mobile-Project-Bootstrap 이용하기
## Bootstrap을 이용한 자기 소개 페이지 입니다.
> 이름 : 강현구<br>
> 직업 : 개발자를 꿈꾸는 학생<br>
> 생년월일 : 2000 / 03 / 10

## SKILLS
![alt 스킬차트](/img/skills.jpg)
1. HTML
2. Java
3. JavaScript
4. Python

## Chat
![alt 운세차트](/img/chat.jpg)
